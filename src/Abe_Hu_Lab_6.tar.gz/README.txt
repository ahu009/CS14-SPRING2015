//Name: Abe Hu
//SID: 861148832
//Date: 5/16/2015

Part a)
    My selection sort function is stable. In a case where there are two equal
    values, my swap function swapping the two values would not execute if the 
    two values are equal, thus not altering their positions after the sort
    functions runs.